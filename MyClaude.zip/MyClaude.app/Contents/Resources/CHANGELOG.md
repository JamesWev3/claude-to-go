# What's new in MyClaude

Each version, newest first. The app shows this in Settings → Updates (a heading is
`## version · date · title`, then one line per change). Keep each line short and plain.

## 0.33.0 · 26 Nov 2026 · bili folds long chats, so Claude never stops to compact

- Chats go through bili (~/dev/bili-wall), a local proxy walled in Anthropic's sandbox, which folds the oldest parts of a long chat as it fills
- The ring under the box shows bili's numbers: how full, what folding has saved, how much came from cache
- A red "bili down" while it isn't answering; the app starts it again by itself
- Chapters stay as the fallback: a chat that can't reach bili uses them, and Settings → Long chats can pick them again

## 0.32.3 · 25 Nov 2026 · Scroll reports that blame the right thing

- Pointer moves also wait while the chat coasts after a flick (AppKit coasts with no wheel events, so hover checks ran all through it)
- A stuttering scroll's report no longer blames what the app did after the scroll stopped: it names a cause only when its sample caught the scroll
- The scroll watch no longer counts the frames its own sample slows, nor names a problem after a function the sample barely saw

## 0.32.2 · 18 Nov 2026 · Smoother scrolling past pictures and under the pointer

- Scrolling onto a gallery of big screenshots no longer stalls: its pictures are shrunk and decoded in the background, and saving your day no longer runs on the main thread
- Scrolling the chat no longer stalls on pointer moves: hover and the cursor wait until the scroll stops, instead of asking macOS where the pointer is at every step. A stutter of 50 ms or more now also records what the app was doing

## 0.32.1 · 17 Nov 2026 · Smoother scrolling after you send

- Scrolling no longer stutters a few seconds after you send a message: the sidebar stopped rebuilding itself for each turn of a chat that's open
- A stuttering scroll's report now names the rows that slowed it

## 0.32.0 · 10 Nov 2026 · Ponytail bar above the box

- When the Ponytail plugin is on, a bar above the box shows its level and this task's numbers, like its band in the terminal
- One line: the level, what the task has cost (and the last turn), Claude's working time, reuse, open callers and tests
- Click the level (or Details) for the four levels as buttons, Copy, and the numbers in columns
- Review and Audit run Ponytail's own commands; Board opens its page of every task
- Copy puts the task's numbers on the clipboard as a Markdown table, the same one the band copies
- The minus button folds the bar to a small handle; the app remembers your choice
- While Claude is working, the levels, Review and Audit wait for the turn to end

## 0.31.3 · 3 Nov 2026 · The chat follows the reply again

- A chat you'd scrolled to just short of the end now follows Claude's reply again: before, a whole reply and its diagrams could sit unseen below, with no Latest button to show it
- A reply that never showed up is logged once, not again as a slow draw when you finally scroll to it

## 0.31.2 · 2 Nov 2026 · No freeze from a big build folder

- The Files tab no longer freezes the app when a repo has thousands of new files (a build folder git isn't ignoring)
- A new folder git doesn't track yet shows as one row with its file count, the way `git status` shows it
- Long file lists show 50 rows, then "Show 100 more"

## 0.31.1 · 2 Nov 2026 · A Dock click fix

- Clicking MyClaude in the Dock no longer crashes a copy whose window never opened

## 0.31.0 · 2 Nov 2026 · Notes

- Notes live at the foot of the sidebar: ⌘P opens them, Return jots one down, and the cursor stays for the next
- Tick a note and it settles for a moment, then tucks under "N done" (Show or Clear)
- Click a note to change it; right-click to copy it, send it to the chat or delete it; drag one into the box
- Shut, the card shows your newest note; drag its top edge to make it taller (double-click: back to normal)
- ⌘Z undoes any change, and edits made in Neovim show up straight away (the file is ~/dev/notes/pad.md)
- Esc in the notes or search field no longer stops Claude

## 0.30.0 · 1 Nov 2026 · Chapters

- Long chats start a new chapter at 150k: Claude writes itself a handover note and carries on, mid-job
- The ring under the box fills towards the next chapter and says which chapter you're in
- The summary card reads "Chapter 2 begins", with the handover note one click away
- Reopened chats open at their latest chapter; "Show earlier chapters" brings the rest
- Settings → While Working → Chapters: 100k, 150k, 200k or Off
- Long chats use roughly half the tokens

## 0.29.0 · 1 Nov 2026 · Back to basics

- Maestro, the new left panel and the notes pad are put away for now
- Kept: popups block hover on the app behind them
- Kept: files open in Neovim
- A Ship it button: ship a finished update from a card in the chat, without sending a message

## 0.28.3 · 1 Nov 2026 · Nothing lights up behind a pop-up

- With the picture viewer, notes pad or search open, the app behind shows no hover, pointer change or tooltip

## 0.28.2 · 1 Nov 2026 · Files open in Neovim

- Every file link opens in Neovim: your running nvim first, else a new kitty window, never IntelliJ
- The notes pad is cleaner: lighter glass, more space, quieter rows and dividers

## 0.28.1 · 1 Nov 2026 · The notes pad

- "Jot a note…" above your account opens the notes pad: one shared pad, saved in ~/dev/notes/pad.md
- ⌘P opens and closes it from anywhere
- Lines starting `- [ ]` become boxes you can tick; ticked ones are struck through
- A 4-line box to type in, and Maestro can add notes too

## 0.28.0 · 1 Nov 2026 · Maestro

- Maestro, a lead in every chat: it hands jobs to a cast of agents (Scout, Builder, Architect, Reviewer) and picks the model for each
- A brake at 85% of your 5-hour window: new agents wait until there's room
- The left panel has two modes, Chats and Maestro: the plan, live agent cards, the 5-hour bar, side quests and your other chats
- Click an agent to see what it's doing now, its steps, the notes you sent it, its memory, pictures and report
- "Tell Maestro about this agent" passes a change to a running agent through Maestro
- Friendlier agent rows in the chat: "Message to <agent>" and "Checked on 4 agents"
- Maestro can put up a plan and side quests on the board for you to tick
- Turn Maestro off for a chat with its chip, or everywhere in Settings; persona chats never have it

## 0.27.2 · 1 Nov 2026 · Agents survive Esc

- Esc or Stop now ends only your turn: background agents keep working instead of all being stopped
- Changing effort applies at once, without restarting claude, so running agents carry on

## 0.27.1 · 1 Nov 2026 · Questions that fit, and no freeze

- Two chats both waiting on you (a question or a permission) no longer freeze the app when you switch between them
- Claude's questions come one at a time when it asks several: a tab for each, ticked once answered, and picking moves you on
- Every option shows its whole description, and a long question scrolls inside the card, so the buttons and the box stay in view
- Skip is always there, and Esc skips too
- After switching chats, 1 2 3 answer the card you're looking at

## 0.27.0 · 1 Nov 2026 · Pictures at the end of a reply

- When Claude makes or looks at pictures you should see (screenshots, mock-ups), they now come together in one card after its last words, above the to-do list
- The card shows one picture big, with its caption and a line on what to look at, and a strip of all of them to pick from
- Click the big picture to look closer: ‹ › or the arrow keys go through the rest, each with its caption
- The app keeps its own copy of each picture, so an old chat still shows them after the files are gone

## 0.26.0 · 31 Oct 2026 · Your day, on a dial

- The rings under Tasks are now a clock of your day: when Claude worked and in which project, your messages, and everything ticked off, round 24 hours
- It shows what's waiting on you now: a dashed line from when each chat started waiting, up to the hand
- Your 5-hour usage window sits round the edge, filled as far as it's used, with a dot where it resets
- Point at anything and the middle says what it was: the chat and how long it ran, your own words, what got done, a quiet stretch
- Click any of it to go there: the chat opens at that message or tick, or the window opens Usage
- ‹ › goes back a day at a time, for yesterday's standup; the projects under it light up their part of the dial
- It costs nothing while you're not using it, and redraws only what changed while you point

## 0.25.2 · 31 Oct 2026 · Short chats follow the reply, big photos don't freeze

- A new chat that you'd scrolled while it was still shorter than the window no longer stays stuck at its top as the reply grows past it: new messages and diagrams come into view as they arrive
- Adding a big photo to the box no longer freezes the app for a couple of seconds: its thumbnail shows at once, and Send waits the moment it takes to get ready

## 0.25.1 · 30 Oct 2026 · Reading back while Claude works

- Scrolled up in a long chat, a new message at the end no longer throws you to the bottom: the chat used to drop its oldest row as each new one came, the page shrank under you, and the scroll jumped to the end and stuttered
- When the busy pill comes or goes mid-scroll, the chat leaves your scroll alone instead of pulling you back to where you were each time the page grew
- A freeze while the screen is asleep (lid shut, the Mac waking briefly by itself) is no longer logged: macOS barely runs the app then
- A to-do list Claude wrote as text is noted once, not again after a later /command

## 0.25.0 · 30 Oct 2026 · Diagram words don't overlap

- A timeline's marks close together no longer write over each other: each label sits on the side of its line away from its neighbour, and moves up a row if it still doesn't fit
- Labels on a map's links that land on one another step apart to the nearest free spot
- A caption or tip that's too long is cut at a word with "…", never mid-word, and the diagram check asks Claude to shorten it first

## 0.24.0 · 30 Oct 2026 · Timeline labels stay on the card

- A timeline's bar labels sit inside the bar when they fit, else beside it on whichever side has room, so the last one no longer runs off the right edge
- A mark's label has its own strip above the bars, and turns to the left of its line near the edge, so it no longer sits on top of the caption

## 0.23.1 · 30 Oct 2026 · No freeze when macOS tiles the window

- The window now tells macOS the smallest and largest it can be in a tile or full screen. macOS used to work that out by solving the layout of the whole window, and once froze the app for 5 seconds doing it

## 0.23.0 · 30 Oct 2026 · Watch the list shrink

- Problems now leave the list once they're fixed. After each update Claude checks, in a private copy of the repo, which ones a change since then put right, and says how; a problem also clears by itself once it stays away long enough while you use a newer version
- The card shows how many are open and fixed, with a chart of the open count over two weeks, and Check now
- Each open problem says how far through its quiet spell it is, whether a fix is on its way, or that it came back; fixed ones fold away under Fixed with how we know, and Claude's silences and the like under Not the app's to fix
- A fixed problem that happens again opens again by itself

## 0.22.2 · 30 Oct 2026 · Stutters say where

- A report of stuttery scrolling now says which list it was (the sidebar, the chat, the panel), and a long sidebar redraws its rows once instead of once per open folder when chats come and go

## 0.22.0 · 29 Oct 2026 · Freezes caught in the act

- After Claude writes a to-do list or draws a diagram, the busy pill says Thinking again, instead of "Writing the to-do list" for as long as the next step takes
- A freeze is now sampled after half a second, not a whole second, so the log can say what the app was stuck on (the last one had ended before its sample started)
- A freeze whose sample only caught the app idle says so, instead of listing the idle wait as where it was stuck, and waits for three before a fix is drafted

## 0.21.0 · 29 Oct 2026 · New icons show at once

- Installing an update now tells macOS the app changed, so a new icon shows in the Dock straight away instead of the old one lingering

## 0.20.0 · 29 Oct 2026 · A new icon

- A new icon, "Duet": two glass bubbles, yours and Claude's, on a blue-violet sky, drawn in the style of macOS 26's own icons and clear down to the smallest size

## 0.19.0 · 29 Oct 2026 · Fixes drafted ahead, applied with a click

- The app no longer changes its own code by itself. A new problem now gets a fix drafted and tested quietly, in a private copy of the repo, with no chat in the sidebar and nothing in ~/dev/myclaude touched
- Each problem in Settings → Updates says where its draft is (drafting, drafted, not the app's doing, fixed in a version); open one to read the cause, the change, how it was proved, and the patch itself
- Apply puts every drafted fix in through one chat, checks it and leaves an update here, so fixing is two clicks: Apply, then Install

## 0.18.0 · 29 Oct 2026 · Copy beside Open

- A code picture's Copy no longer sits on top of its Open button: they're side by side, and Copy takes the code itself

## 0.17.0 · 29 Oct 2026 · New kinds of picture, and the app fixes itself

- Eight new kinds of picture, each drawn by the app rather than typed: state machines and maps laid out like real graphs (loops go round the outside), a trace that lights each value as it changes, a timeline, a request going down through layers to where it failed, real lines of code with numbered notes, blast-radius rings, and a yes/no grid
- Hover a box in a graph to light its arrows; click a line of code to open it at that line
- The app notices when scrolling can't keep up and when it stays busy for half a minute, and logs where the time went
- New problems now fix themselves: a chat opens in the background in ~/dev/myclaude, finds the cause, and leaves an update here (Settings → Updates → Fix problems by itself; one at a time, up to 4 a day)
- Freezes now say where the app was stuck again (newer macOS names the main thread differently)
- A diagram drawn through the tool is no longer logged as "came as text"

## 0.16.0 · 29 Oct 2026 · Lists and pictures as data

- Claude now hands over the to-do list through the app's own tool instead of writing it, so it can't come out as raw text; the card always sits after Claude's last words
- Every diagram, chart and box drawing comes through a tool too, which checks it (shapes, tips, boxes that line up, no wide symbols) and tells Claude what to fix before you see it
- Charts: bar and line, with values on the bars and a readout when you hover
- A list from an older chat with a slightly different name in brackets still shows as its card
- A VPN or relay tunnel no longer counts as being online when the Wi-Fi is off, and the waiting tray has Send now in case the Mac gets it wrong

## 0.15.0 · 28 Oct 2026 · Ready for a bad connection

- "Offline" shows in the top bar when the internet drops, and what you send waits above the box, then goes by itself when you're back
- While Claude retries, the busy pill says why and when the next try goes, instead of just "Retrying"
- A turn the connection cut short shows one card with Carry on (no more error twice), and carries on by itself once you're back online
- If Claude says nothing for 90 seconds mid-turn, the pill says so and offers Stop and retry
- The app watches itself: freezes (with where it was stuck), replies that didn't get drawn, claude stopping, API errors and crashes go in a problem log
- An orange dot on the gear means a new problem; Settings → Updates lists them, and Fix with Claude opens a chat with them in the box

## 0.14.0 · 28 Oct 2026 · The box keeps up

- The box grows as soon as a word wraps, even when it's macOS's grey word suggestion that pushed it over, instead of hiding the new line until a few more letters
- It shrinks back when the suggestion goes, too

## 0.13.0 · 28 Oct 2026 · One band along the top

- The soft band along the top of the window now runs behind the sidebar and the panel too, so they float over one screen instead of showing their edges at the top

## 0.12.0 · 28 Oct 2026 · One screen

- The sidebar floats over the same colour as the chat, like the panel on the right, instead of sitting in a lighter strip of its own

## 0.11.0 · 28 Oct 2026 · Running anywhere, lists that arrive

- What's running in your other chats shows as one chip under the box ("2 running in blink-api"); click it to stop one or go to that chat
- Chats and folders in the sidebar with something running show a small terminal mark and how many
- A to-do list being written shows as its card with the spark turning and a count, instead of raw lines that jump into the card at the end

## 0.10.0 · 28 Oct 2026 · What's running, under the box

- Shells and agents Claude has running show as chips under the box, each with its clock; click one for its latest output, Stop, or Background it (Claude carries on while it runs)
- A chat with something still running in the background no longer goes to sleep (which stopped it)
- Type @ and part of a name to pick a file from the chat's folder; Claude reads it with your message
- Up in an empty box brings back what you sent, and again for the one before; Down comes back
- The box no longer flickers when your typing wraps onto a new line
- Long chats open at once: a 285 MB one took 3 seconds, now a blink
- The loading bar on /compact and the blinking block at the start of a reply no longer redraw the window 30 times a second

## 0.9.0 · 28 Oct 2026 · No more freeze on Enter

- Pressing Enter on a command while the slash menu is still open (say /compact typed in full) no longer freezes the whole app

## 0.8.0 · 28 Oct 2026 · Busy means busy

- A message sent while Claude was busy (or compacting) shows Claude working again when it's picked up: the spinner in the sidebar and the line above the box no longer vanish

## 0.7.0 · 28 Oct 2026 · Settings, tidied

- In Settings, a page scrolls up to a line under its heading and stops there, instead of showing above it
- Less empty space at the top of Settings: the heading and Search sit just under the window buttons

## 0.6.0 · 28 Oct 2026 · Faster, and yours to name

- Replies stream in using about a fifth of the CPU they did, and the chat no longer redraws itself for every word
- Scrolling up through open "Ran" boxes no longer jumps: long output stops at a Show all pill instead of scrolling inside the chat
- Code blocks and box diagrams size themselves first time, and only show their buttons while the pointer is over them
- Click the chat you're in (in the sidebar), or its name now shown in the top bar, to rename it; `claude --resume` sees the new name too
- New chat in… (⇧⌘N, or the folder button in the sidebar) starts a chat in any folder, or makes a new one
- Folders opened out with Show more fold back with Show less
- Thought lines with a summary open when clicked, whatever Settings → Thinking says
- Done replaces the star sky: rings for the day, a bar for each day of the week, and that day's items as rows
- A new Settings window: sections down the side, search, a live preview, and nothing sliding under the window buttons
- Updates wait here in Settings → Updates, with this history, instead of needing a message to install
- About 300 lines of old code taken out

## 0.5.0 · 28 Oct 2026 · Beyond the terminal

- The green window button no longer crashes the app, and the window buttons hold their place
- Search inside every chat from ⌘K, opening at the message with the words highlighted
- Pictures in the chat, with a viewer
- Move a chat between Max and Team from its account chip; Team-only folders stay on Team
- Right-click menus everywhere, and diagrams save as A4 PDF or PNG
- Click any part of a diagram for Claude's note on it, or to ask about it
- "Type this" cards for edits you type yourself, ticking off when the file matches
- A colour for each folder, the branch's pull request in the top bar, and a usage ring in the menu bar
- Quiet chats sleep after half an hour; blank chats don't linger; the empty screen offers unfinished work

## 0.4.0 · 27 Oct 2026 · Steadier window

- Window buttons stay put when you drag a divider, and glide with the sidebar
- The Files tab in headed groups, with nothing cut off at the top

## 0.3.0 · 27 Oct 2026 · Context at a glance

- A Context card in the Usage tab
- Every new chat fills the Usage tab before you send anything

## 0.2.0 · 27 Oct 2026 · Liquid Glass

- The whole look redone in Liquid Glass: floating sidebar, inspector and box
- Diagrams drawn natively from Claude's sketches
- A pointing hand on everything you can click

## 0.1.0 · 27 Oct 2026 · A Mac app of its own

- MyClaude rebuilt as a native Swift app around your own claude
- Live thinking, command cards, and the sidebar by account and persona
- Close buttons, a tray for waiting messages, and files that open in Neovim
